# Anleitung zum Ausführen der "VM Implementation" 


## A. Mit Kommandozeile 

### 1. Clojure installieren 
MacOS: ```brew install clojure/tools/clojure``` <br>
Windows weiß ich nicht :/

### 2. Navigiere in den Ordner vm1 selber

### 3. Führe aus: 
```clojure -M -m vm1 "<path>""```

Der Pfad sollte dabei relativ zum momentanen Ordner (vm1) sein. Die benötigten Tests liegen auch alle in diesem Projekt.

### 4. Die .asm-Dateien liegen jeweils auf Ebene der .vm-Dateien

